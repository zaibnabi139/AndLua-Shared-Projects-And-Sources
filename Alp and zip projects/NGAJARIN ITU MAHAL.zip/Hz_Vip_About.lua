require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "AndLua"
import "http"
import "android.content.Context"
import "android.content.Intent"
import "android.provider.Settings"
import "android.net.Uri"
import "android.graphics.Typeface"
import "Hz_Vip_Aboutz"
载入页面(Hz_Vip_Aboutz)

function CircleButton(view,InsideColor,radiu,InsideColor1)
import "android.graphics.drawable.GradientDrawable"
drawable = GradientDrawable()
drawable.setShape(GradientDrawable.RECTANGLE)
drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
drawable.setColor(InsideColor)
drawable.setStroke(3, InsideColor1)
view.setBackgroundDrawable(drawable)
end

function hzmods.onClick()
activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/channel/UCJwzagNb-pAbBV0dCRMXirw")))
end

function telegram.onClick()
activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://t.me/andluaofficial")))
end

function donate.onClick()
activity.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://paypal.me/lontong12")))
end

function back.onClick()
activity.newActivity("main")
activity.finish()
end

CircleButton(hzmods,0x3f000000,0,0xfff800ff)
CircleButton(telegram,0x3f000000,0,0xfff800ff)
CircleButton(donate,0x3f000000,0,0xfff800ff)
CircleButton(back,0x3f000000,0,0xffffffff)




